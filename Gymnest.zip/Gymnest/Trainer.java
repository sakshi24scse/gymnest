import java.io.Serializable;

public class Trainer implements Serializable {
    private int id;
    private String name;
    private String expertise;

    public Trainer(int id, String name, String expertise) {
        this.id = id;
        this.name = name;
        this.expertise = expertise;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getExpertise() { return expertise; }
    public void setExpertise(String expertise) { this.expertise = expertise; }

    @Override
    public String toString() {
        return id + "," + name + "," + expertise;
    }

    public static Trainer fromString(String str) {
        String[] parts = str.split(",");
        if(parts.length == 3) {
            int id = Integer.parseInt(parts[0]);
            String name = parts[1];
            String expertise = parts[2];
            return new Trainer(id, name, expertise);
        }
        return null;
    }
}
