import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final Plain service = new Plain();

    public static void main(String[] args) {
        System.out.println("Welcome to Gymnest Console App!");
        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Manage Members");
            System.out.println("2. Manage Trainers");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            int choice = getIntInput();

            switch (choice) {
                case 1 -> manageMembers();
                case 2 -> manageTrainers();
                case 3 -> {
                    System.out.println("Exiting... Goodbye!");
                    System.exit(0);
                }
                default -> System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void manageMembers() {
        while (true) {
            System.out.println("\n--- Manage Members ---");
            System.out.println("1. Add Member");
            System.out.println("2. View All Members");
            System.out.println("3. Update Member");
            System.out.println("4. Delete Member");
            System.out.println("5. Back");
            System.out.print("Enter choice: ");
            int choice = getIntInput();

            try {
                switch (choice) {
                    case 1 -> addMember();
                    case 2 -> viewMembers();
                    case 3 -> updateMember();
                    case 4 -> deleteMember();
                    case 5 -> { return; }
                    default -> System.out.println("Invalid choice! Please try again.");
                }
            } catch (IOException e) {
                System.out.println("Error handling file: " + e.getMessage());
            }
        }
    }

    private static void addMember() throws IOException {
        System.out.println("Enter Member ID (positive integer): ");
        int id = getPositiveIntInput();

        if (existsMember(id)) {
            System.out.println("Member with ID " + id + " already exists.");
            return;
        }

        System.out.print("Enter Member Name: ");
        String name = scanner.nextLine();
        if (name.isBlank()) {
            System.out.println("Name cannot be empty.");
            return;
        }

        System.out.print("Enter Member Age (10-100): ");
        int age = getIntInputInRange(10, 100);

        System.out.print("Enter Membership Type (Basic/Premium/VIP): ");
        String type = scanner.nextLine();
        if (!type.equalsIgnoreCase("Basic") && !type.equalsIgnoreCase("Premium") && !type.equalsIgnoreCase("VIP")) {
            System.out.println("Invalid membership type.");
            return;
        }

        Member m = new Member(id, name, age, type);
        service.addMember(m);
        System.out.println("Member added successfully.");
    }

    private static void viewMembers() throws IOException {
        List<Member> members = service.getAllMembers();
        if (members.isEmpty()) {
            System.out.println("No members found.");
            return;
        }
        System.out.println("Member List:");
        for (Member m : members) {
            System.out.printf("ID: %d, Name: %s, Age: %d, Membership: %s%n",
                    m.getId(), m.getName(), m.getAge(), m.getMembershipType());
        }
    }

    private static void updateMember() throws IOException {
        System.out.print("Enter Member ID to update: ");
        int id = getPositiveIntInput();

        List<Member> members = service.getAllMembers();
        Member member = members.stream().filter(m -> m.getId() == id).findFirst().orElse(null);
        if (member == null) {
            System.out.println("Member not found.");
            return;
        }

        System.out.print("Enter new Name (leave blank to keep " + member.getName() + "): ");
        String name = scanner.nextLine();
        if (!name.isBlank()) member.setName(name);

        System.out.print("Enter new Age (10-100, or 0 to keep " + member.getAge() + "): ");
        int age = getIntInput();
        if (age != 0) {
            if (age < 10 || age > 100) {
                System.out.println("Invalid age input, keeping old age.");
            } else {
                member.setAge(age);
            }
        }

        System.out.print("Enter new Membership Type (Basic/Premium/VIP, or blank to keep " + member.getMembershipType() + "): ");
        String type = scanner.nextLine();
        if (!type.isBlank()) {
            if (!type.equalsIgnoreCase("Basic") && !type.equalsIgnoreCase("Premium") && !type.equalsIgnoreCase("VIP")) {
                System.out.println("Invalid membership type, keeping old value.");
            } else {
                member.setMembershipType(type);
            }
        }

        if(service.updateMember(member))
            System.out.println("Member updated successfully.");
        else
            System.out.println("Failed to update member.");
    }

    private static void deleteMember() throws IOException {
        System.out.print("Enter Member ID to delete: ");
        int id = getPositiveIntInput();

        if(service.deleteMember(id))
            System.out.println("Member deleted successfully.");
        else
            System.out.println("Member not found.");
    }

    private static boolean existsMember(int id) throws IOException {
        List<Member> members = service.getAllMembers();
        return members.stream().anyMatch(m -> m.getId() == id);
    }

    private static void manageTrainers() {
        while (true) {
            System.out.println("\n--- Manage Trainers ---");
            System.out.println("1. Add Trainer");
            System.out.println("2. View All Trainers");
            System.out.println("3. Update Trainer");
            System.out.println("4. Delete Trainer");
            System.out.println("5. Back");
            System.out.print("Enter choice: ");
            int choice = getIntInput();

            try {
                switch (choice) {
                    case 1 -> addTrainer();
                    case 2 -> viewTrainers();
                    case 3 -> updateTrainer();
                    case 4 -> deleteTrainer();
                    case 5 -> { return; }
                    default -> System.out.println("Invalid choice! Please try again.");
                }
            } catch (IOException e) {
                System.out.println("Error handling file: " + e.getMessage());
            }
        }
    }

    private static void addTrainer() throws IOException {
        System.out.print("Enter Trainer ID (positive integer): ");
        int id = getPositiveIntInput();

        if (existsTrainer(id)) {
            System.out.println("Trainer with ID " + id + " already exists.");
            return;
        }

        System.out.print("Enter Trainer Name: ");
        String name = scanner.nextLine();
        if (name.isBlank()) {
            System.out.println("Name cannot be empty.");
            return;
        }

        System.out.print("Enter Expertise (e.g. Cardio, Weights): ");
        String expertise = scanner.nextLine();
        if (expertise.isBlank()) {
            System.out.println("Expertise cannot be empty.");
            return;
        }

        Trainer t = new Trainer(id, name, expertise);
        service.addTrainer(t);
        System.out.println("Trainer added successfully.");
    }

    private static void viewTrainers() throws IOException {
        List<Trainer> trainers = service.getAllTrainers();
        if (trainers.isEmpty()) {
            System.out.println("No trainers found.");
            return;
        }
        System.out.println("Trainer List:");
        for (Trainer t : trainers) {
            System.out.printf("ID: %d, Name: %s, Expertise: %s%n",
                    t.getId(), t.getName(), t.getExpertise());
        }
    }

    private static void updateTrainer() throws IOException {
        System.out.print("Enter Trainer ID to update: ");
        int id = getPositiveIntInput();

        List<Trainer> trainers = service.getAllTrainers();
        Trainer trainer = trainers.stream().filter(t -> t.getId() == id).findFirst().orElse(null);
        if (trainer == null) {
            System.out.println("Trainer not found.");
            return;
        }

        System.out.print("Enter new Name (leave blank to keep " + trainer.getName() + "): ");
        String name = scanner.nextLine();
        if (!name.isBlank()) trainer.setName(name);

        System.out.print("Enter new Expertise (leave blank to keep " + trainer.getExpertise() + "): ");
        String expertise = scanner.nextLine();
        if (!expertise.isBlank()) trainer.setExpertise(expertise);

        if(service.updateTrainer(trainer))
            System.out.println("Trainer updated successfully.");
        else
            System.out.println("Failed to update trainer.");
    }

    private static void deleteTrainer() throws IOException {
        System.out.print("Enter Trainer ID to delete: ");
        int id = getPositiveIntInput();

        if(service.deleteTrainer(id))
            System.out.println("Trainer deleted successfully.");
        else
            System.out.println("Trainer not found.");
    }

    private static boolean existsTrainer(int id) throws IOException {
        List<Trainer> trainers = service.getAllTrainers();
        return trainers.stream().anyMatch(t -> t.getId() == id);
    }

    // Helper methods for input validation
    private static int getIntInput() {
        try {
            String line = scanner.nextLine();
            return Integer.parseInt(line.trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input! Please enter a valid number.");
            return -1;
        }
    }

    private static int getPositiveIntInput() {
        int num;
        do {
            num = getIntInput();
            if (num <= 0) System.out.print("Please enter a positive integer: ");
        } while (num <= 0);
        return num;
    }

    private static int getIntInputInRange(int min, int max) {
        int num;
        do {
            num = getIntInput();
            if (num < min || num > max) System.out.print("Enter a number between " + min + " and " + max + ": ");
        } while (num < min || num > max);
        return num;
    }
}
