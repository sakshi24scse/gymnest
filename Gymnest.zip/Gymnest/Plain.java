import java.io.*;
import java.util.*;

public class Plain {

    private static final String MEMBER_FILE = "members.txt";
    private static final String TRAINER_FILE = "trainers.txt";

    // CRUD Members
    public void addMember(Member m) throws IOException {
        List<Member> members = getAllMembers();
        members.add(m);
        saveMembers(members);
    }

    public List<Member> getAllMembers() throws IOException {
        List<Member> members = new ArrayList<>();
        File file = new File(MEMBER_FILE);
        if(!file.exists()) return members;

        try(BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while((line = br.readLine()) != null) {
                Member m = Member.fromString(line);
                if(m != null) members.add(m);
            }
        }
        return members;
    }

    public boolean updateMember(Member updatedMember) throws IOException {
        List<Member> members = getAllMembers();
        boolean found = false;
        for(int i=0; i<members.size(); i++) {
            if(members.get(i).getId() == updatedMember.getId()) {
                members.set(i, updatedMember);
                found = true;
                break;
            }
        }
        if(found) saveMembers(members);
        return found;
    }

    public boolean deleteMember(int id) throws IOException {
        List<Member> members = getAllMembers();
        boolean removed = members.removeIf(m -> m.getId() == id);
        if(removed) saveMembers(members);
        return removed;
    }

    private void saveMembers(List<Member> members) throws IOException {
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(MEMBER_FILE))) {
            for(Member m : members) {
                bw.write(m.toString());
                bw.newLine();
            }
        }
    }

    // CRUD Trainers
    public void addTrainer(Trainer t) throws IOException {
        List<Trainer> trainers = getAllTrainers();
        trainers.add(t);
        saveTrainers(trainers);
    }

    public List<Trainer> getAllTrainers() throws IOException {
        List<Trainer> trainers = new ArrayList<>();
        File file = new File(TRAINER_FILE);
        if(!file.exists()) return trainers;

        try(BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while((line = br.readLine()) != null) {
                Trainer t = Trainer.fromString(line);
                if(t != null) trainers.add(t);
            }
        }
        return trainers;
    }

    public boolean updateTrainer(Trainer updatedTrainer) throws IOException {
        List<Trainer> trainers = getAllTrainers();
        boolean found = false;
        for(int i=0; i<trainers.size(); i++) {
            if(trainers.get(i).getId() == updatedTrainer.getId()) {
                trainers.set(i, updatedTrainer);
                found = true;
                break;
            }
        }
        if(found) saveTrainers(trainers);
        return found;
    }

    public boolean deleteTrainer(int id) throws IOException {
        List<Trainer> trainers = getAllTrainers();
        boolean removed = trainers.removeIf(t -> t.getId() == id);
        if(removed) saveTrainers(trainers);
        return removed;
    }

    private void saveTrainers(List<Trainer> trainers) throws IOException {
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(TRAINER_FILE))) {
            for(Trainer t : trainers) {
                bw.write(t.toString());
                bw.newLine();
            }
        }
    }
}
